package com.example.entity;

public enum PlaceStatus {
    AVAILABLE,
    RESERVED,
    OUT_OF_SERVICE
}
