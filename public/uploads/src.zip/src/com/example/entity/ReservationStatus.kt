package com.example.entity

public enum class ReservationStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}