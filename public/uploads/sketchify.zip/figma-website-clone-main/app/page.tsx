'use client'
import NavBar from "@/components/NavBar";
// import {useGSAP} from "@gsap/react";
// import gsap from "gsap";
// import {useRef} from "react";
import Hero from "@/components/hero";

export default function Home() {

//   const logoRef = useRef(null)
// useGSAP(()=>{
//     const tl = gsap.timeline({repeat: -1, yoyo: true})
//     tl.from(logoRef.current, {rotate: 0, duration: 1})
//     tl.to(logoRef.current, {rotate: 360, duration: 1})
// }, {dependencies: [],})

  return (
    <div className="bg-dotted-spacing-6 bg-dotted-gray-400 bg-[#EBE2FF]">
        {/*TODO: change the bg to make it change according to the section that's visible*/}

      <NavBar />
      <Hero/>
    </div>
  );
}
