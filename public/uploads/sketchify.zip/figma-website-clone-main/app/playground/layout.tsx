import { Work_Sans } from "next/font/google";
import "@/styles/globals.css";
import { Room } from "@/app/playground/Room";

const workSans = Work_Sans({
  subsets: ["latin"],
  variable: "--font-work-sans",
  weight: ["400", "600", "700"],
});

export default function PlaygroundLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className={`${workSans.className} bg-primary-grey-200`}>
      <Room>{children}</Room>
    </div>
  );
}
