import Image from 'next/image';
import Link from "next/link";

export default function NavBar() {
    return (
        <nav className="flex justify-between items-center px-12 py-3 shadow-md bg-[#EBE2FF] sticky">
            <div className={"flex justify-center items-center gap-2"}>
            <Image src="/assets/images/logo.png" alt="logo" width={40} height={40} />
                <h1 className={"text-2xl font-bold text-black"}>Sketchify</h1>
            </div>
            <div>
                <Link href={"/playground"}>
                <button className={"flex items-center justify-between gap-1 px-5 py-1 bg-[#6147FF] rounded-xl"}>
                <Image src="/assets/icons/hat.svg" alt="logo" width={27} height={27}/>
                    <h1 className={"text-2xl font-bold text-white"}>Start</h1>
                </button>
                </Link>
            </div>
        </nav>
    );
}