import Image from "next/image";
import gsap from "gsap";
import SplitType from "split-type";
import { useGSAP } from "@gsap/react";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger)

export default function Hero() {
  useGSAP(() => {
    const heroText = SplitType.create("#heading", { types: "words" });
    const heroChars = heroText.words;
    console.log(heroChars);
    gsap.to(".star1", { rotation: 360, duration: 5, repeat: -1, ease: "none" });
    gsap.to(".star2", { rotation: 360, duration: 5, repeat: -1, ease: "none" });
    gsap.to(".star3", { rotation: 360, duration: 5, repeat: -1, ease: "none" });

    gsap.set("#heading", { autoAlpha: 1 })
      gsap.set(heroChars, { yPercent: 100 })
      const initialAnimation = gsap.to(heroChars, {
          yPercent: 0,
          ease: "sine.out",
          stagger: {from: "start", amount: 0.5, ease: "power1.out"},
          onComplete: activateScrollTrigger
      })
      function activateScrollTrigger() {
        gsap.to(heroChars, {
            yPercent: -100,
            stagger: {from: "end"},
            scrollTrigger:{
                trigger: "#heading",
                start: "top top",
                end: "bottom top",
                scrub: 1
            }
        })
      }
    // gsap.fromTo(
    //   heroChars,
    //   {
    //     y: 100,
    //     opacity: 0,
    //   },
    //   {
    //     y: 0,
    //     opacity: 1,
    //     stagger: 0.05,
    //     duration: 1,
    //     ease: "power4.out",
    //   },
    // );
    gsap.fromTo(
      ".pen",
      {
        y: 100,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        stagger: 0.05,
        duration: 1,
        ease: "power4.out",
      },
    );
    gsap.fromTo(
      ".frame",
      {
        y: 100,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        stagger: 0.05,
        duration: 1,
        ease: "power4.out",
      },
    );
    gsap.fromTo(
      ".create",
      {
        y: 100,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        stagger: 0.05,
        duration: 1,
        ease: "power4.out",
      },
    );
  });
  return (
    <main className="h-screen w-screen flex justify-center">
      <Image
        src="/assets/icons/star1.svg"
        alt="star1"
        width={190}
        height={190}
        className={"star1 absolute top-[7rem] left-[4rem]"}
      />
      <Image
        src="/assets/icons/star2.svg"
        alt="star2"
        width={110}
        height={110}
        className={"star2 absolute top-[7rem] right-[8rem]"}
      />
      <Image
        src="/assets/icons/star3.svg"
        alt="star3"
        width={155}
        height={155}
        className={"star3 absolute top-[22rem] right-[4rem]"}
      />
      <Image
        src="/assets/icons/circles.svg"
        alt="circles"
        width={210}
        height={200}
        className={"circles absolute top-[23rem] left-[7rem]"}
      />
      <h1
        id="heading"
        className="clip-path-polygon mt-52 text-[4rem] font-semibold leading-[1.15] text-black text-center w-[50%] relative"
      >
        <span className={"imagine text-[#FF5050] inline-flex"}>
          Imagine
          <div>
            <Image
              src="/assets/icons/pen.svg"
              className="ml-1 pen"
              alt="pen"
              width={39}
              height={39}
            />
          </div>
        </span>
        ,{" "}
        <span className={"text-[#5061FF] inline-flex"}>
          Sketch
          <div>
            <Image
              src="/assets/icons/Frame.svg"
              className="ml-1 frame"
              alt="pen"
              width={39}
              height={39}
            />
          </div>
        </span>{" "}
        and{" "}
        <span className={"text-[#CF05E1] inline-flex"}>
          {" "}
          Create
          <div>
            <Image
              src="/assets/icons/create.svg"
              className="ml-1 create"
              alt="pen"
              width={39}
              height={39}
            />
          </div>
        </span>{" "}
        you favorite websites
      </h1>
    </main>
  );
}

/**
 * Rules to follow for smooth animations using GSAP:
 *
 * - Avoid using filters as they are terrible for performance, especially in Safari.
 * - In most cases, performance issues are related to graphics rendering in the browser, not GSAP. Focus on making it easier for the browser to render stuff quickly.
 * - Keep the area of change on the screen as tight as possible. The more pixels that must change on each tick, the harder it is on the browser.
 * - SVGs can be expensive to animate, especially if they're big. Rendering bitmaps/raster images is fast, but SVGs are typically fabricating pixels on-the-fly via math, which is expensive.
 * - Set `pointer-events: none` wherever you can so that the browser doesn't have to worry about pointer event handling, bubbling, etc. However, you need pointer functionality on many things like buttons, links, etc. so you can't set `pointer-events: none` on everything.
 * - Avoid animating properties that affect layout like width/height/top/left. Instead, animate transforms wherever you can because they don't affect layout.
 * - When animating transforms, leverage GSAP's shortcuts wherever possible (like x, y, scaleX, scaleY, rotation) rather than generic string-based "transform" stuff. For example, `x: 50` is much better than `transform: "translateX(50px)"`.
 * - Don't have animations running when they're totally outside of the viewport (invisible). It's a waste of resources.
 * - If you are pushing the renderer hard in the browser, consider switching to something like PixiJS that can leverage `<canvas>` and WebGL. It's a headache to build, but it can be way faster at rendering.
 * - Never have CSS transitions/animations applied to elements that are also being animated with GSAP.
 * - Try using `will-change: transform` on elements that are tough on the renderer (big/heavy).
 *
 * Additional points:
 *
 * - Use `requestAnimationFrame` for animations instead of `setInterval` or `setTimeout`.
 * - Use the `opacity` and `transform` properties for animations as they don't trigger layout or paint, leading to higher performance.
 * - Avoid animating properties that trigger layout recalculations, such as `width`, `height`, `top`, `left`, `right`, `bottom`, `margin`, and `padding`.
 * - Use hardware acceleration by applying `transform: translateZ(0)` or `will-change: transform` to the element. This can make the animation smoother, but be careful as it can increase memory usage.
 */
